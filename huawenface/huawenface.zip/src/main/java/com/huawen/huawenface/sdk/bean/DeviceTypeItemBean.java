package com.huawen.huawenface.sdk.bean;

public class DeviceTypeItemBean {
    private String content;
    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
