package com.huawen.huawenface.sdk.bean;

public class BaseBean {
}
