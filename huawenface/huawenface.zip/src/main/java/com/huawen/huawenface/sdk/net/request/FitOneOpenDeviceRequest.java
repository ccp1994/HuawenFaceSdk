package com.huawen.huawenface.sdk.net.request;

public class FitOneOpenDeviceRequest extends FitOneBaseRequest{
    private String dev_id;
    private String dev_type;
    private String personId;

    public String getDev_id() {
        return dev_id;
    }

    public void setDev_id(String dev_id) {
        this.dev_id = dev_id;
    }

    public String getDev_type() {
        return dev_type;
    }

    public void setDev_type(String dev_type) {
        this.dev_type = dev_type;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }
}
