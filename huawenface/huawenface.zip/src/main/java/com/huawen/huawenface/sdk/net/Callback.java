package com.huawen.huawenface.sdk.net;

public interface Callback<T>{
        void callback(Result<T>result);        
    }
