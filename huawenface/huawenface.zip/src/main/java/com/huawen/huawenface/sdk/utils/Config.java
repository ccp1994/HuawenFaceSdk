package com.huawen.huawenface.sdk.utils;

/**
 * Created by ZengYinan.
 * Date: 2018/9/7 11:42
 * Email: 498338021@qq.com
 * Desc:
 */
public interface Config {
    String URL = "http://service.image.myqcloud.com/face/identify";
    String GROUP_ID = "nsVGj9jCFBUp.1735";//每个健身房的不一样
    long APPID = 1254179741;//OK
    String SECRETID = "AKIDXzIQM7MclpigaJiGwYyCD7pStAFGqlDD";//OK
    String SECRETKEY = "2xmPrCPTM6eFj3B5Yv9D6oKftwoUzIPK";//OK
    String BUCKETNAME = "fitone-face-1254179741";//any
    String USER_ID = "2044016561";//any
}
